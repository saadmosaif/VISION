"use client"

import { useState } from "react"
import Link from "next/link"
import { HoodieCard } from "@/components/hoodie-card"

type Category = "all" | "hoodies" | "tshirts" | "shorts" | "accessories"

export default function Lookbook() {
  const [activeCategory, setActiveCategory] = useState<Category>("all")

  const products = [
    // Hoodies
    {
      id: 1,
      name: "VisionDrop Essence",
      price: 149.99,
      category: "hoodies",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 2,
      name: "Underground Collective",
      price: 154.99,
      category: "hoodies",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 3,
      name: "Rave Culture",
      price: 159.99,
      category: "hoodies",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 4,
      name: "Limited Drop",
      price: 199.99,
      category: "hoodies",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    // T-Shirts
    {
      id: 5,
      name: "Movement Tee",
      price: 49.99,
      category: "tshirts",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 6,
      name: "Underground Crown",
      price: 54.99,
      category: "tshirts",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    // Shorts
    {
      id: 7,
      name: "Rave Shorts",
      price: 79.99,
      category: "shorts",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 8,
      name: "Street Shorts",
      price: 84.99,
      category: "shorts",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    // Accessories
    {
      id: 9,
      name: "VisionDrop Ashtray",
      price: 24.99,
      category: "accessories",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 10,
      name: "Movement Stickers Pack",
      price: 9.99,
      category: "accessories",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 11,
      name: "Underground Cap",
      price: 34.99,
      category: "accessories",
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
  ]

  const filteredProducts = activeCategory === "all" ? products : products.filter((p) => p.category === activeCategory)

  return (
    <main className="min-h-screen bg-neutral-950">
      {/* Header */}
      <section className="w-full py-16 md:py-24 bg-neutral-900 border-b border-neutral-800">
        <div className="container mx-auto px-4">
          <Link href="/" className="text-green-400 text-sm mb-4 inline-block hover:text-green-300">
            ← Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">VisionDrop Lookbook</h1>
          <p className="text-lg text-neutral-400">Explore the complete collection</p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="w-full py-12 bg-gradient-to-r from-neutral-900 via-neutral-850 to-neutral-900 sticky top-0 z-40 border-b border-green-500/30 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 md:gap-4 overflow-x-auto pb-2 md:pb-0">
            {[
              { id: "all", label: "All Items", icon: "◆" },
              { id: "hoodies", label: "Hoodies", icon: "⊙" },
              { id: "tshirts", label: "T-Shirts", icon: "▪" },
              { id: "shorts", label: "Shorts", icon: "◈" },
              { id: "accessories", label: "Accessories", icon: "✦" },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as Category)}
                className={`relative px-6 py-3 whitespace-nowrap transition-all duration-300 group ${
                  activeCategory === cat.id ? "text-green-400" : "text-neutral-400 hover:text-green-300"
                }`}
              >
                {/* Icon */}
                <span
                  className={`text-lg mr-2 inline-block transition-transform duration-300 ${
                    activeCategory === cat.id ? "scale-125 text-green-500" : "group-hover:scale-110"
                  }`}
                >
                  {cat.icon}
                </span>

                {/* Label */}
                <span className="relative">
                  {cat.label}

                  {/* Animated underline */}
                  <span
                    className={`absolute left-0 bottom-0 h-0.5 transition-all duration-300 ${
                      activeCategory === cat.id
                        ? "w-full bg-gradient-to-r from-green-500 to-transparent"
                        : "w-0 bg-[#BD14E3] group-hover:w-full"
                    }`}
                  />
                </span>

                {/* Glow effect for active */}
                {activeCategory === cat.id && (
                  <span className="absolute inset-0 rounded blur opacity-50 -z-10 bg-[#BD14E3] group-hover:bg-[#BD14E3] transition-all" />
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="w-full py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <HoodieCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                image1={product.image1}
                image2={product.image2}
              />
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-neutral-500 text-lg">No products found in this category</p>
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
