import { HoodieCard } from "@/components/hoodie-card"
import { AutoSliderBanner } from "@/components/auto-slider-banner"
import Link from "next/link"

export default function Home() {
  const hoodies = [
    {
      id: 1,
      name: "VisionDrop Essence",
      price: 149.99,
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 2,
      name: "Underground Collective",
      price: 154.99,
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 3,
      name: "Rave Culture",
      price: 159.99,
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
    {
      id: 4,
      name: "Limited Drop",
      price: 199.99,
      image1: "https://i.pinimg.com/736x/92/06/56/920656e03f09691d871e149b5dad8f7f.jpg",
      image2: "https://i.pinimg.com/736x/94/d3/14/94d31436dfc73fcf93058089f69ffd96.jpg",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col">
      {/* Full-screen Auto-sliding Banner */}
      <AutoSliderBanner />

      {/* Manifesto Teaser Section */}
      <section className="w-full py-20 md:py-32 bg-neutral-950 relative overflow-hidden border-t border-neutral-800">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#BD14E3] rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-3xl"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-green-400 text-sm md:text-base font-mono mb-4">VISIONDROP MOVEMENT</p>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">We Are The Underground</h2>
            <p className="text-lg md:text-xl text-neutral-400 mb-8 leading-relaxed">
              VisionDrop celebrates the culture of connection, rebellion, and authenticity. We're more than a
              brand—we're a movement connecting underground communities worldwide through style and shared vision.
            </p>
            <Link
              href="/about"
              className="inline-block px-8 py-3 bg-[#BD14E3] text-black font-semibold rounded hover:bbg-[#BD14E3] transition-colors"
            >
              Read Our Story
            </Link>
          </div>
        </div>
      </section>

      {/* Product Section */}
      <section id="product-section" className="w-full py-12 md:py-24 bg-black-900 rounded-3xl">
        <div className="container mx-auto px-4">
          <h2 className="mb-8 text-3xl font-bold text-center text-gray-100">Latest Collection</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {hoodies.map((hoodie) => (
              <HoodieCard key={hoodie.id} {...hoodie} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Drops Section */}
      <section id="featured-drops-section" className="w-full py-20 md:py-32 bg-neutral-900 rounded-3xl ">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <p className="text-purple-400 text-sm md:text-base font-mono mb-3">LATEST COLLECTION</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white">Current Drops</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {hoodies.map((hoodie) => (
              <HoodieCard key={hoodie.id} {...hoodie} />
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link
              href="/lookbook"
              className="inline-block px-8 py-3 border border-gray-500 text-black-400 font-semibold rounded hover:bg-gray-100 hover:text-black transition-all"
            >
              View Full Lookbook
            </Link>
          </div>
        </div>
      </section>

      {/* Community Teaser */}
      <section className="w-full py-20 md:py-32 bg-neutral-950 border-t border-neutral-800">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <p className="text-purple-400 text-sm md:text-base font-mono mb-3">PEOPLE OF VISIONDROP</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">The Movement Lives In You</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="h-64 bg-neutral-800 rounded overflow-hidden border border-neutral-700 hover:border-purple-500 transition-colors cursor-pointer">
                <div className="w-full h-full bg-gradient-to-br from-neutral-700 to-neutral-900 flex items-center justify-center">
                  <span className="text-neutral-600">Community Member</span>
                </div>
              </div>
              <div className="h-64 bg-neutral-800 rounded overflow-hidden border border-neutral-700 hover:border-purple-500 transition-colors cursor-pointer">
                <div className="w-full h-full bg-gradient-to-br from-neutral-700 to-neutral-900 flex items-center justify-center">
                  <span className="text-neutral-600">Community Member</span>
                </div>
              </div>
              <div className="h-64 bg-neutral-800 rounded overflow-hidden border border-neutral-700 hover:border-purple-500 transition-colors cursor-pointer">
                <div className="w-full h-full bg-gradient-to-br from-neutral-700 to-neutral-900 flex items-center justify-center">
                  <span className="text-neutral-600">Community Member</span>
                </div>
              </div>
            </div>
            <div className="mt-12 text-center">
              <Link
                href="/community"
                className="inline-block px-8 py-3 bg-purple-600 text-white font-semibold rounded hover:bg-purple-700 transition-colors rounded-2xl"
              >
                Join The Movement
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
